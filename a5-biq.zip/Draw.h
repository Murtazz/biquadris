#ifndef __DRAW_H__
#define __DRAW_H__
#include <iostream>
#include "Window.h"




void drawPixel(int a, int b, Xwindow& board);

void drawInBoard(Xwindow &board);

#endif