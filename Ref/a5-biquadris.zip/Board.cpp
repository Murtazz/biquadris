#include "Board.hpp"

Board::Board(){}
Board::~Board(){}

