#ifndef DRAW_H
#define DRAW_H
#include <iostream>
#include "window.h"




void drawPx(int a, int b, Xwindow& board);

void drawMainBoard(Xwindow &board, bool sound);

#endif
